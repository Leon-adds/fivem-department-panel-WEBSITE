<?php
require_once(__DIR__ . "/config.php");
session_start();
$staffRank = $_SESSION['staffrank'];

//SUPERVISORS AND ABOVE ONLY
if(intval($staffRank) <= 3  && intval($staffRank) != 0)
{
    // YOU CAN STAY :D
}
else
{
    header('Location: login.php');
}

$_SESSION["playerID"] = $_GET["id"];

$actionMessage = "";
if(isset($_GET['actionSuccess']))
{
  $actionMessage = '<div class="alert alert-info alert-dismissible fade show" style="text-align: center;" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button> Your action was successful!</div>';
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Profiles | <?php echo $DEPARTMENT_NAME; ?> Panel</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A Department Panel by Hamz#0001" name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body class="left-side-menu-dark">

        <div id="wrapper">

        <!--HEADER-->
        <?php include "includes/header.inc.php"; ?>

        <!--NAVBAR-->
        <?php include "includes/navbar.inc.php"; ?>

        <!-- FOOTER -->
        <?php include "includes/footer.inc.php"; ?>

        <!-- CONTENT -->

            <div class="content-page">
                <div class="content">
                    <div class="container-fluid"> 
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">

                                    </div>
                                    <h4 class="page-title">Profiles</h4>
                                </div>
                            </div>
                        </div>  

                    <?php if($actionMessage){echo $actionMessage;} ?>
                    <?php include "includes/profile.inc.php"; ?>

                    </div>
                </div> 
            </div>
        </div>

        <div class="rightbar-overlay"></div>
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/morris-js/morris.min.js"></script>
        <script src="assets/libs/raphael/raphael.min.js"></script>
        <script src="assets/libs/custombox/custombox.min.js"></script>
        <script src="assets/js/pages/dashboard-4.init.js"></script>
        <script src="assets/js/app.min.js"></script>
        <script src="assets/libs/peity/jquery.peity.min.js"></script>
        <script src="assets/libs/jquery-knob/jquery.knob.min.js"></script>
        <script src="assets/libs/jquery-sparkline/jquery.sparkline.min.js"></script>
        <script src="assets/libs/moment/moment.min.js"></script>
        <script src="assets/libs/jquery-scrollto/jquery.scrollTo.min.js"></script>
        <script src="assets/libs/sweetalert2/sweetalert2.min.js"></script>
        <script src="assets/js/pages/jquery.chat.js"></script>
        <script src="assets/js/pages/jquery.todo.js"></script>
        <script src="assets/js/pages/widgets.init.js"></script>

        
    </body>
</html>