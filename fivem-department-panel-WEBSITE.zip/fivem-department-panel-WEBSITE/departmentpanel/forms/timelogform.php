<?php
require_once(__DIR__ . "/../actions/discord_functions.php");
require_once(__DIR__ . "/../config.php");
require_once(__DIR__ . "/../actions/points.php");

session_start();

if (empty($_SESSION['logged_in']))
{
    header('Location: ../login.php');
}

$userID = $_SESSION['staffid'];
$name = $_SESSION['staffname'];
$tag = $_SESSION['stafftag'];
$discordid = $_SESSION['staffid'];

$discordname = $name . "#" . $tag . "";

function timeLog($hours, $minutes, $extra, $goodbad) {
    global $DEPARTMENT_NAME, $TIMELOG_CHANNEL_ID;
    
    $discordid = $_SESSION['staffid'];
    $userID = $_SESSION['staffid'];
    $duration = "" . $hours . " Hours  :  " . $minutes . " Minutes";
    if ($extra == "") {
        $extra = "Empty";
    }

    // POINTS
    if ($hours >= 5) {
       updatePoints("timelog5", $userID);
    } else if ($hours >= 4) {
        updatePoints("timelog4", $userID);
    } else if ($hours >= 3) {
        updatePoints("timelog3", $userID);
    } else if ($hours >= 2) {
        updatePoints("timelog2", $userID);
    } else {
        updatePoints("timelog1", $userID);
    } 
    // POINTS
    $durHours = intval(htmlspecialchars($hours) * 3600);
    $durMinutes = intval(htmlspecialchars($minutes) * 60);
    $durationdb = intval($durHours) + intval($durMinutes);

    $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);

    $stmt = $pdo->prepare("INSERT INTO timelogs (discordid, time, info, goodbad) VALUES (?, ?, ?, ?)");
    $result = $stmt->execute(array($discordid, $durationdb, $extra, $goodbad));


    $log = new richEmbed("{$DEPARTMENT_NAME} Timelog","<@{$discordid}> has submitted a Time Log");
    $log->addField("Duration [HH:MM]:", $duration, false);
    $log->addField("How was the patrol?", $goodbad, false);
    $log->addField("Brief Description Of Patrol:", $extra, false);
    $log = $log->build();
    sendLog($log, $TIMELOG_CHANNEL_ID);

    header('Location: ../index.php?actionSuccessTimelog');
}

if (isset($_POST['submit_btn']))
{
    $goodbad = htmlentities($_POST['goodbad']);
    $hours = htmlentities($_POST['hours']);
    $minutes = htmlentities($_POST['minutes']);
    $extra = htmlentities($_POST['extra']);
    timeLog($hours, $minutes, $extra, $goodbad);
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Time Log | <?php echo $DEPARTMENT_NAME; ?> Panel</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A Department Panel by Hamz#0001" name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <link href="../assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="../assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="../assets/css/app.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body class="left-side-menu-dark">

        <div id="wrapper">

        <!--HEADER-->
        <?php include "../includes/header.inc.php"; ?>

        <!--NAVBAR-->
        <?php include "../includes/navbar.inc.php"; ?>

        <!-- FOOTER -->
        <?php include "../includes/footer.inc.php"; ?>

        <!-- CONTENT -->

            <div class="content-page">
                <div class="content">
                    <div class="container-fluid"> 
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">

                                    </div>
                                    <h4 class="page-title">Time Log</h4>
				                </div>
                            </div>
                        </div>    
  
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-body">

                                        <form id="form" action="#" method="post"> 
                                            <div class="form-group mb-3">
                                                <label for="discordname">Discord Name</label>
                                                <input disabled value="<?php echo $discordname; ?>" id="discordname" name="discordname" type="text" class="form-control">
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="discordid">Discord ID</label>
                                                <input disabled value="<?php echo $discordid; ?>"type="text" id="discordid" name="discordid" class="form-control">
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="hours">Hours</label>
                                                <input required required type="text" placeholder="" data-v-max="24" data-v-min="0" id="hours" name="hours" class="form-control autonumber">
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="minutes">Minutes</label>
                                                <input required required type="text" placeholder="" data-v-max="60" data-v-min="0" id="minutes" name="minutes" class="form-control autonumber">
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="goodbad">How was your patrol?</label>
                                                <select required class="form-control" name="goodbad">
                                                    <option value="Good">Good</option>
                                                    <option value="Bad">Bad</option>
                                                    <option value="Decent">Decent</option>
                                                </select>
                                             </div>
                                            <div class="form-group mb-3">
                                                <label for="extra">Brief Description Of Patrol</label>
                                                <input required id="extra" name="extra" type="text" class="form-control">
                                            </div>

                                            <button type="submit" name="submit_btn" class="btn btn-outline-<?php echo $BUTTON_TYPE; ?> waves-effect waves-light">Submit</button>
                                        </form>

                                    </div>
                                </div>
                            </div>
                            <?php include "../includes/timelog.inc.php"; ?>
                         </div>
                     </div>

                </div> 
            </div>
        </div>

        <!-- JS PLUGINS -->
        <div class="rightbar-overlay"></div>
        <script src="../assets/js/vendor.min.js"></script>
        <script src="../assets/libs/morris-js/morris.min.js"></script>
        <script src="../assets/libs/raphael/raphael.min.js"></script>
        <script src="../assets/libs/jquery-mask-plugin/jquery.mask.min.js"></script>
        <script src="../assets/libs/autonumeric/autoNumeric-min.js"></script>
        <script src="../assets/js/pages/dashboard-4.init.js"></script>
        <script src="../assets/js/pages/form-masks.init.js"></script>
        <script src="../assets/js/app.min.js"></script>
        <script src="../assets/js/script.js"></script>
        
    </body>
</html>
