<?php
session_start();
session_unset();
session_destroy();
if(ENABLE_API_SECURITY === true)
    setcookie('dagaafd', null, -1, "/");

header("Location: ../login.php");
exit();
?>