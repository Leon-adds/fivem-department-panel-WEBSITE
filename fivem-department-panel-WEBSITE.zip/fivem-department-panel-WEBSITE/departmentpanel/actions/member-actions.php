<?php
require_once(__DIR__ . "/../config.php");
require_once(__DIR__ . "/discord_functions.php");
require_once(__DIR__ . "/points.php");
session_start();

$playerID = $_SESSION['playerID'];
$userID = $_SESSION['staffid'];

if (isset($_POST['warn_player_btn']))
{
    addWarn();
    updatePoints("warning", $userID);
}
if (isset($_POST['note_player_btn']))
{
    addNote();
}
if (isset($_POST['strike_player_btn']))
{
    addStrike();
    updatePoints("strike", $userID);
}
if (isset($_POST['praise_player_btn']))
{
    addPraise();
    updatePoints("praise", $userID);
}
if (isset($_GET['warnID']))
{
    removeWarning();
    updatePoints("unwarn", $userID);
}
if (isset($_GET['noteID']))
{
    removeNote();
}
if (isset($_GET['strikeID']))
{
    removeStrike();
    updatePoints("unstrike", $userID);
}
if (isset($_GET['praiseID']))
{
    removePraise();
    updatePoints("unpraise", $userID);
}
if (isset($_GET['timelogID']))
{
    removeTimelog();
    updatePoints("untimelog", $userID);
}
if (isset($_GET['announcementID']))
{
    removeAnnouncement();
}
if (isset($_GET['documentID']))
{
    removeDocument();
}
if (isset($_GET['userID']))
{
    removeUser();
}
if (isset($_GET['certificationID']))
{
    removeCertification();
}


function removeCertification() {
	global $CERTLOG_CHANNEL_ID;

	$certificationID = htmlspecialchars($_GET['certificationID']);
	
	// Just used for making sure we get back to the correct user profile
	$staffMemberID = $_SESSION['currentStaffStatSearchedID'];
	$staffMembersName = $_SESSION['currentStaffStatSearchedName'];
	$staffid = $_SESSION['staffid'];
	$discordtag = "<@".$staffid.">";
	
	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}

	$pdo->query("DELETE FROM certification WHERE ID='$certificationID'");

    $log = new richEmbed("CERTIFICATION REMOVED", "{$staffMembersName} has had a certification removed.");
    $log->addField("By user:", $discordtag, true);
    $log = $log->build();
    sendLog($log, $CERTLOG_CHANNEL_ID);
	
	//COMPLEX RETURN POST
	$_SESSION['OVERRIDEID'] = $staffMemberID;

	header('Location: ../profile.php?actionSuccess');
}

function addCertification($certification) {
	global $CERTLOG_CHANNEL_ID;

    $discordid = $_SESSION['staffid'];
    $currentDiscordID = $_SESSION['currentStaffStatSearchedDiscordID'];
    $currentName = $_SESSION['currentStaffStatSearchedName'];
    $staffMemberID = $_SESSION['currentStaffStatSearchedID'];

    try{
        $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
    } catch(PDOException $ex)
    {
        echo "Could not connect -> ".$ex->getMessage();
        die();
    }

    $stmt = $pdo->prepare("INSERT INTO certification (certification, discordid) VALUES (?, ?)");
    $result = $stmt->execute(array($certification, $currentDiscordID));

    $log = new richEmbed("CERTIFICATION ADDED","<@{$discordid}> has added {$certification} for <@{$currentDiscordID}>");
    $log = $log->build();
    sendLog($log, $CERTLOG_CHANNEL_ID);

	$_SESSION['OVERRIDEID'] = $staffMemberID;
    header('Location: ../profile.php?actionSuccess');

}  

if (isset($_POST['certification_btn']))
{
	$certification = htmlentities($_POST['certification']);
    addCertification($certification);
}   


function addWarn()
{
	global $WARN_CHANNEL_ID;
	// SHOULD BE ASSIGNED AS THE PERSON WHOS GETTING THE WARNING
	$StaffDiscordID = $_SESSION["currentStaffStatSearchedDiscordID"];
	$staffName = $_SESSION['staffname'];
	$staffSteamID = $_SESSION['staffid'];
	$reason = htmlspecialchars($_POST['strike']);
	
	//Just used for making sure we get back to the correct user profile
	$staffMemberID = $_SESSION['currentStaffStatSearchedID'];

	$discordtag = "<@".$staffSteamID.">";

	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}

	$time = gmmktime() + 3600;

    $stmt = $pdo->prepare("INSERT INTO warnings (member_discordid, reason, senders_discordid, senders_name, time) VALUES (?, ?, ?, ?, ?)");
    $result = $stmt->execute(array($StaffDiscordID, $reason, $staffSteamID, $staffName, $time));
	
	$staffMembersName = $_SESSION['currentStaffStatSearchedName'];

    $log = new richEmbed("NEW WARNING", "**{$staffMembersName}** has been warned for: ` {$reason} `");
    $log->addField("By user:", $discordtag, true);
    $log = $log->build();
    sendLog($log, $WARN_CHANNEL_ID);
	
	//COMPLEX RETURN POST
	$_SESSION['OVERRIDEID'] = $staffMemberID;
	header('Location: ../profile.php?actionSuccess');
}

function addNote()
{
	global $NOTE_CHANNEL_ID;
	// SHOULD BE ASSIGNED AS THE PERSON WHOS GETTING THE STRIKE
	$StaffDiscordID = $_SESSION["currentStaffStatSearchedDiscordID"];
	$staffName = $_SESSION['staffname'];
	$staffSteamID = $_SESSION['staffid'];
	$reason = htmlspecialchars($_POST['strike']);
	
	//Just used for making sure we get back to the correct user profile
	$staffMemberID = $_SESSION['currentStaffStatSearchedID'];

	$discordtag = "<@".$staffSteamID.">";
	
	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}

	$time = gmmktime() + 3600;

    $stmt = $pdo->prepare("INSERT INTO notes (member_discordid, reason, senders_discordid, senders_name, time) VALUES (?, ?, ?, ?, ?)");
    $result = $stmt->execute(array($StaffDiscordID, $reason, $staffSteamID, $staffName, $time));
	
	$staffMembersName = $_SESSION['currentStaffStatSearchedName'];

    $log = new richEmbed("NEW NOTE", "**{$staffMembersName}** has been noted for: ` {$reason} `");
    $log->addField("By user:", $discordtag, true);
    $log = $log->build();
    sendLog($log, $NOTE_CHANNEL_ID);
	
	//COMPLEX RETURN POST
	$_SESSION['OVERRIDEID'] = $staffMemberID;
	header('Location: ../profile.php?actionSuccess');
}

function addStrike()
{
	global $STRIKE_CHANNEL_ID;
	// SHOULD BE ASSIGNED AS THE PERSON WHOS GETTING THE STRIKE
	$StaffDiscordID = $_SESSION["currentStaffStatSearchedDiscordID"];
	$staffName = $_SESSION['staffname'];
	$staffSteamID = $_SESSION['staffid'];
	$reason = htmlspecialchars($_POST['strike']);
	
	//Just used for making sure we get back to the correct user profile
	$staffMemberID = $_SESSION['currentStaffStatSearchedID'];

	$discordtag = "<@".$staffSteamID.">";
	
	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}

	$time = gmmktime() + 3600;

    $stmt = $pdo->prepare("INSERT INTO strikes (member_discordid, reason, senders_discordid, senders_name, time) VALUES (?, ?, ?, ?, ?)");
    $result = $stmt->execute(array($StaffDiscordID, $reason, $staffSteamID, $staffName, $time));
	
	$staffMembersName = $_SESSION['currentStaffStatSearchedName'];

    $log = new richEmbed("NEW STRIKE", "**{$staffMembersName}** has been striked for: ` {$reason} `");
    $log->addField("By user:", $discordtag, true);
    $log = $log->build();
    sendLog($log, $STRIKE_CHANNEL_ID);
	
	//COMPLEX RETURN POST
	$_SESSION['OVERRIDEID'] = $staffMemberID;
	header('Location: ../profile.php?actionSuccess');
}

function addPraise()
{
	global $PRAISE_CHANNEL_ID;
	// SHOULD BE ASSIGNED AS THE PERSON WHOS GETTING THE STRIKE
	$StaffDiscordID = $_SESSION["currentStaffStatSearchedDiscordID"];
	$staffName = $_SESSION['staffname'];
	$staffSteamID = $_SESSION['staffid'];
	$reason = htmlspecialchars($_POST['strike']);
	
	//Just used for making sure we get back to the correct user profile
	$staffMemberID = $_SESSION['currentStaffStatSearchedID'];

	$discordtag = "<@".$staffSteamID.">";
	
	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}

	$time = gmmktime() + 3600;
	
    $stmt = $pdo->prepare("INSERT INTO praises (member_discordid, reason, senders_discordid, senders_name, time) VALUES (?, ?, ?, ?, ?)");
    $result = $stmt->execute(array($StaffDiscordID, $reason, $staffSteamID, $staffName, $time));
	
	$staffMembersName = $_SESSION['currentStaffStatSearchedName'];

    $log = new richEmbed("NEW PRAISE", "**{$staffMembersName}** has been praised for: ` {$reason} `");
    $log->addField("By user:", $discordtag, true);
    $log = $log->build();
    sendLog($log, $PRAISE_CHANNEL_ID);
	
	//COMPLEX RETURN POST
	$_SESSION['OVERRIDEID'] = $staffMemberID;
	header('Location: ../profile.php?actionSuccess');
}


function removePraise()
{
	global $REMOVEACTION_CHANNEL_ID;
	$praiseID = htmlspecialchars($_GET['praiseID']);
	
	//Just used for making sure we get back to the correct user profile
	$staffMemberID = $_SESSION['currentStaffStatSearchedID'];
	$staffName = $_SESSION['staffname'];
	$staffid = $_SESSION['staffid'];
	$discordtag = "<@".$staffid.">";

	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}
	
	// GET STRIKE BEFORE DELETING IT SO IT CAN BE LOGGED
	$strikeData = "";
	$getStrike = $pdo->query("SELECT * FROM praises WHERE ID='$praiseID'");
	foreach($getStrike as $strikeRow)
	{
		$strikeData = $strikeRow['reason'];
	}

	$pdo->query("DELETE FROM praises WHERE ID='$praiseID'");

	$staffMembersName = $_SESSION['currentStaffStatSearchedName'];

    $log = new richEmbed("PRAISE REMOVED", $staffMembersName . " who was praised for ` ".$strikeData." ` has now been unpraised.");
    $log->addField("By user:", $discordtag, true);
    $log = $log->build();
    sendLog($log, $REMOVEACTION_CHANNEL_ID);
	
	//COMPLEX RETURN POST
	$_SESSION['OVERRIDEID'] = $staffMemberID;
	header('Location: ../profile.php?actionSuccess');
}

function removeTimelog()
{
	global $REMOVEACTION_CHANNEL_ID;
	$timelogID = htmlspecialchars($_GET['timelogID']);
	
	//Just used for making sure we get back to the correct user profile
	$staffMemberID = $_SESSION['currentStaffStatSearchedID'];
	$staffName = $_SESSION['staffname'];
	$staffid = $_SESSION['staffid'];
	$discordtag = "<@".$staffid.">";

	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}

	$pdo->query("DELETE FROM timelogs WHERE ID='$timelogID'");

	$staffMembersName = $_SESSION['currentStaffStatSearchedName'];

    $log = new richEmbed("TIMELOG REMOVED", $staffMembersName . " has a timelog removed.");
    $log->addField("By user:", $discordtag, true);
    $log = $log->build();
    sendLog($log, $REMOVEACTION_CHANNEL_ID);
	
	//COMPLEX RETURN POST
	$_SESSION['OVERRIDEID'] = $staffMemberID;
	header('Location: ../profile.php?actionSuccess');
}

function removeAnnouncement()
{
	global $REMOVEACTION_CHANNEL_ID;
	$announcementID = htmlspecialchars($_GET['announcementID']);
	
	$staffName = $_SESSION['staffname'];
	$staffid = $_SESSION['staffid'];
	$discordtag = "<@".$staffid.">";

	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}

	$pdo->query("DELETE FROM announcements WHERE ID='$announcementID'");

    $log = new richEmbed("ANNOUNCEMENT REMOVED","{$discordtag} has removed an announcement.");
    $log = $log->build();
    sendLog($log, $REMOVEACTION_CHANNEL_ID);
	
	header('Location: ../headdashboard.php');
}

function removeDocument()
{
	global $REMOVEACTION_CHANNEL_ID;
	$documentID = htmlspecialchars($_GET['documentID']);
	
	$staffName = $_SESSION['staffname'];
	$staffid = $_SESSION['staffid'];
	$discordtag = "<@".$staffid.">";

	$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);

	$pdo->query("DELETE FROM documents WHERE ID='$documentID'");

    $log = new richEmbed("DOCUMENT REMOVED","{$discordtag} has removed a document.");
    $log = $log->build();
    sendLog($log, $REMOVEACTION_CHANNEL_ID);
	
	header('Location: ../headdashboard.php');
}

function removeWarning()
{
	global $REMOVEACTION_CHANNEL_ID;
	$warnID = htmlspecialchars($_GET['warnID']);
	
	//Just used for making sure we get back to the correct user profile
	$staffMemberID = $_SESSION['currentStaffStatSearchedID'];
	$staffName = $_SESSION['staffname'];
	$staffid = $_SESSION['staffid'];
	$discordtag = "<@".$staffid.">";

	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}
	
	// GET STRIKE BEFORE DELETING IT SO IT CAN BE LOGGED
	$strikeData = "";
	$getStrike = $pdo->query("SELECT * FROM warnings WHERE ID='$warnID'");
	foreach($getStrike as $strikeRow)
	{
		$strikeData = $strikeRow['reason'];
	}

	$pdo->query("DELETE FROM warnings WHERE ID='$warnID'");

	$staffMembersName = $_SESSION['currentStaffStatSearchedName'];

    $log = new richEmbed("WARNING REMOVED", $staffMembersName . " who was warned for ` ".$strikeData." ` has now been unwarned.");
    $log->addField("By user:", $discordtag, true);
    $log = $log->build();
    sendLog($log, $REMOVEACTION_CHANNEL_ID);
	
	//COMPLEX RETURN POST
	$_SESSION['OVERRIDEID'] = $staffMemberID;
	header('Location: ../profile.php?actionSuccess');
}

function removeNote()
{
	global $REMOVEACTION_CHANNEL_ID;
	$noteID = htmlspecialchars($_GET['noteID']);
	
	//Just used for making sure we get back to the correct user profile
	$staffMemberID = $_SESSION['currentStaffStatSearchedID'];
	$staffName = $_SESSION['staffname'];
	$staffid = $_SESSION['staffid'];
	$discordtag = "<@".$staffid.">";

	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}
	
	// GET STRIKE BEFORE DELETING IT SO IT CAN BE LOGGED
	$strikeData = "";
	$getStrike = $pdo->query("SELECT * FROM notes WHERE ID='$noteID'");
	foreach($getStrike as $strikeRow)
	{
		$strikeData = $strikeRow['reason'];
	}

	$pdo->query("DELETE FROM notes WHERE ID='$noteID'");

	$staffMembersName = $_SESSION['currentStaffStatSearchedName'];

    $log = new richEmbed("NOTE REMOVED", $staffMembersName . " who was noted for ` ".$strikeData." ` has now been unnoted.");
    $log->addField("By user:", $discordtag, true);
    $log = $log->build();
    sendLog($log, $REMOVEACTION_CHANNEL_ID);
	
	//COMPLEX RETURN POST
	$_SESSION['OVERRIDEID'] = $staffMemberID;
	header('Location: ../profile.php?actionSuccess');
}

function removeStrike()
{
	global $REMOVEACTION_CHANNEL_ID;
	$strikeID = htmlspecialchars($_GET['strikeID']);
	
	//Just used for making sure we get back to the correct user profile
	$staffMemberID = $_SESSION['currentStaffStatSearchedID'];
	$staffName = $_SESSION['staffname'];
	$staffid = $_SESSION['staffid'];
	$discordtag = "<@".$staffid.">";

	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}
	
	// GET STRIKE BEFORE DELETING IT SO IT CAN BE LOGGED
	$strikeData = "";
	$getStrike = $pdo->query("SELECT * FROM strikes WHERE ID='$strikeID'");
	foreach($getStrike as $strikeRow)
	{
		$strikeData = $strikeRow['reason'];
	}

	$pdo->query("DELETE FROM strikes WHERE ID='$strikeID'");

	$staffMembersName = $_SESSION['currentStaffStatSearchedName'];

    $log = new richEmbed("STRIKE REMOVED", $staffMembersName . " who was striked for ` ".$strikeData." ` has now been unstriked.");
    $log->addField("By user:", $discordtag, true);
    $log = $log->build();
    sendLog($log, $REMOVEACTION_CHANNEL_ID);
	
	//COMPLEX RETURN POST
	$_SESSION['OVERRIDEID'] = $staffMemberID;
	header('Location: ../profile.php?actionSuccess');
}

function removeUser()
{
	global $REMOVEACTION_CHANNEL_ID;
	$userID = htmlspecialchars($_GET['userID']);
	
	//Just used for making sure we get back to the correct user profile
	$staffMemberID = $_SESSION['currentStaffStatSearchedID'];
	$staffName = $_SESSION['staffname'];
	$staffid = $_SESSION['staffid'];
	$discordtag = "<@".$staffid.">";

	try{
		$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
	} catch(PDOException $ex)
	{
		echo "Could not connect -> ".$ex->getMessage();
		die();
	}

	$pdo->query("DELETE FROM users WHERE ID='$userID'");

	$staffMembersName = $_SESSION['currentStaffStatSearchedName'];

    $log = new richEmbed("USER REMOVED", "{$staffMembersName} has been removed.");
    $log->addField("By user:", $discordtag, true);
    $log = $log->build();
    sendLog($log, $REMOVEACTION_CHANNEL_ID);
	
	//COMPLEX RETURN POST
	$_SESSION['OVERRIDEID'] = $staffMemberID;
	header('Location: ../stats.php');
}

function changeCallsign($callsign) {
	global $CALLSIGN_CHANNEL_ID;
    $discordid = $_SESSION['staffid'];
    $currentDiscordID = $_SESSION['currentStaffStatSearchedDiscordID'];
    $currentName = $_SESSION['currentStaffStatSearchedName'];
    $staffMemberID = $_SESSION['currentStaffStatSearchedID'];

    try{
        $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
    } catch(PDOException $ex)
    {
        echo "Could not connect -> ".$ex->getMessage();
        die();
    }

    $result = $pdo->query("UPDATE users SET name='$currentName', callsign='$callsign' WHERE discordid='$currentDiscordID'");


    $log = new richEmbed("CALLSIGN UPDATED","<@{$discordid}> has changed the callsign for <@{$currentDiscordID}> to `` {$callsign} ``");
    $log = $log->build();
    sendLog($log, $CALLSIGN_CHANNEL_ID);

	$_SESSION['OVERRIDEID'] = $staffMemberID;
    header('Location: ../profile.php?actionSuccess');
}

if (isset($_POST['callsign_btn']))
{
    $callsign = htmlentities($_POST['callsign']);
    changeCallsign($callsign);
}

?>
