<?php
require_once(__DIR__ . "/../config.php");

try{
    $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
} catch(PDOException $ex)
{
    echo "Could not connect -> ".$ex->getMessage();
    die();
}

/**
 * @param string $id
 * @return string $userPoints
 */
function getPoints($id) {
    global $pdo;
    $userPoints = "";
    $result = $pdo->query("SELECT points FROM users WHERE discordid='$id'");
    foreach($result as $row)
    {
        $userPoints = $row['points'];
    }
    return $userPoints;
}

/**
 * @param string $id
 * @param string $newPoints
 */
function setPoints($id, $newPoints) {
    global $pdo;
    $update = $pdo->query("UPDATE users SET points='$newPoints' WHERE discordid='$id'");
}

/**
 * @param string $id
 * @param string $type
 */
function updatePoints($type, $id) {
    $coefficients = array(
        "warning" => 15,
        "strike" => 25,
        "praise" => 15,
        "timelog1" => 1,
        "timelog2" => 2,
        "timelog3" => 3,
        "timelog4" => 4,
        "timelog5" => 5
    );

    $userPoints = getPoints($id);
    floatval($userPoints);

    switch($type) {
        case "warning":
            $userPoints = $userPoints - $coefficients["warning"];
            break;
        case "strike";
            $userPoints = $userPoints - $coefficients["strike"];
            break;
        case "praise":
            $userPoints = $userPoints + $coefficients["praise"];
            break;
        case "timelog1":
            $userPoints = $userPoints + $coefficients["timelog1"];
            break;
        case "timelog2":
            $userPoints = $userPoints + $coefficients["timelog2"];
            break;
        case "timelog3":
            $userPoints = $userPoints + $coefficients["timelog3"];
            break;
        case "timelog4":
            $userPoints = $userPoints + $coefficients["timelog4"];
            break;
        case "timelog5":
            $userPoints = $userPoints + $coefficients["timelog5"];
            break;
        case "unwarn":
            $userPoints = $userPoints + $coefficients["warning"];
            break;
        case "unstrike":
            $userPoints = $userPoints + $coefficients["strike"];
            break;
        case "unpraise":
            $userPoints = $userPoints - $coefficients["praise"];
            break;
        case "untimelog":
            $userPoints = $userPoints - $coefficients["timelog5"];
            break;
        default:
            throw new InvalidArgumentException("Invalid point action");
            break;
    }
	
	$RoundedScore = strval(round($userPoints, 2));
    setPoints($id, $RoundedScore);
}

?>