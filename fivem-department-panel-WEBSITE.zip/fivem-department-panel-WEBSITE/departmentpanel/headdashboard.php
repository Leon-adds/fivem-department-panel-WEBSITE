<?php
require_once(__DIR__ . "/actions/discord_functions.php");
require_once(__DIR__ . "/config.php");
session_start();
$staffRank = $_SESSION['staffrank'];

//HEADS AND ABOVE ONLY
if(intval($staffRank) <= 1  && intval($staffRank) != 0)
{
    // YOU CAN STAY :D
}
else
{
    header('Location: login.php');
}

function addAnnouncement($announcement, $channelid, $atitle) {
    $discordid = $_SESSION['staffid'];

    try{
        $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
    } catch(PDOException $ex)
    {
        echo "Could not connect -> ".$ex->getMessage();
        die();
    }

    $stmt = $pdo->prepare("INSERT INTO announcements (details, discordid) VALUES (?, ?)");
    $result = $stmt->execute(array($announcement, $discordid));


    $log = new richEmbed("{$atitle}","By <@{$discordid}>");
    $log->addField("‎‎‏‏‎** **", $announcement, false);
    $log = $log->build();
    sendLog($log, $channelid);

    header('Location: headdashboard.php');
}

if (isset($_POST['announcement_btn']))
{
    $atitle = htmlentities($_POST['atitle']);
    $announcement = htmlentities($_POST['announcement']);
    $channelid = htmlentities($_POST['channelid']);
    addAnnouncement($announcement, $channelid, $atitle);
}

function addDoc($doctitle, $doclink) {
    global $DOCUMENTSLOG_CHANNEL_ID;

    $discordid = $_SESSION['staffid'];

    try{
        $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
    } catch(PDOException $ex)
    {
        echo "Could not connect -> ".$ex->getMessage();
        die();
    }

    $stmt = $pdo->prepare("INSERT INTO documents (title, link) VALUES (?, ?)");
    $result = $stmt->execute(array($doctitle, $doclink));

    $log = new richEmbed("NEW DOCUMENT","<@{$discordid}> has added a new document: {$doctitle}");
    $log = $log->build();
    sendLog($log, $DOCUMENTSLOG_CHANNEL_ID);

    header('Location: headdashboard.php');
}

if (isset($_POST['docs_btn']))
{
    $doctitle = htmlentities($_POST['doctitle']);
    $doclink = htmlentities($_POST['doclink']);
    addDoc($doctitle, $doclink);
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Head Dashboard | <?php echo $DEPARTMENT_NAME; ?> Panel</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A Department Panel by Hamz#0001" name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />

    </head>

    <body class="left-side-menu-dark">

        <div id="wrapper">

        <!--HEADER-->
        <?php include "includes/header.inc.php"; ?>

        <!--NAVBAR-->
        <?php include "includes/navbar.inc.php"; ?>

        <!-- FOOTER -->
        <?php include "includes/footer.inc.php"; ?>

        <!-- CONTENT -->

            <div class="content-page">
                <div class="content">
                    <div class="container-fluid"> 
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Heads Dashboard</h4>
                                </div>
                            </div>
                        </div>    
                        <div class="row">
                            <div class="col-lg-6">
                                <h4 class="page-title">Announcements</h4>
                                <div class="card">
                                    <div class="card-body">

                                        <form id="form" action="#" method="post">
                                            <div class="form-group mb-4">
                                                <label for="atitle">Title</label>
                                                <input placeholder="" id="atitle" name="atitle" type="text" class="form-control">
                                            </div> 
                                            <div class="form-group mb-4">
                                                <label for="announcement">Details</label>
                                                <textarea required placeholder="" id="announcement" name="announcement" type="text" class="form-control"></textarea>
                                            </div>
                                            <div class="form-group mb-4">
                                                <label for="channelid">Channel ID</label>
                                                <input placeholder="" id="channelid" name="channelid" type="text" class="form-control">
                                            </div>

                                            <button type="submit" name="announcement_btn" class="btn btn-outline-<?php echo $BUTTON_TYPE; ?> waves-effect waves-light">Send Announcement</button>
                                        </form>

                                    </div>
                                </div>
                            </div>
                            <?php include "includes/announcement.inc.php"; ?>
                       </div>

                        <div class="row">
                            <div class="col-lg-6">
                                <h4 class="page-title">Documents</h4>
                                <div class="card">
                                    <div class="card-body">

                                        <form id="form" action="#" method="post"> 
                                            <div class="form-group mb-4">
                                                <label for="doctitle">Title</label>
                                                <input required placeholder="" id="doctitle" name="doctitle" type="text" class="form-control">
                                            </div>
                                            <div class="form-group mb-4">
                                                <label for="doclink">Link</label>
                                                <input required placeholder="" id="doclink" name="doclink" type="text" class="form-control">
                                            </div>

                                            <button type="submit" name="docs_btn" class="btn btn-outline-<?php echo $BUTTON_TYPE; ?> waves-effect waves-light">Add Document</button>
                                        </form>

                                    </div>
                                </div>
                            </div>
                            <?php include "includes/document.inc.php"; ?>
                       </div>

                    </div>
                </div> 
            </div>
        </div>

        <!-- JS PLUGINS -->
        <div class="rightbar-overlay"></div>
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/morris-js/morris.min.js"></script>
        <script src="assets/libs/raphael/raphael.min.js"></script>
        <script src="assets/js/pages/dashboard-4.init.js"></script>
        <script src="assets/js/app.min.js"></script>
        
    </body>
</html>