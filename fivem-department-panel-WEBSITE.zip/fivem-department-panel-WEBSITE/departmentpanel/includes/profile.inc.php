<?php
require_once(__DIR__ . "/../config.php");
require_once(__DIR__ . "/../actions/discord_functions.php");
require_once(__DIR__ . "/../actions/points.php");

session_start();

$staffRank = $_SESSION['staffrank'];
 
//SUPERVISORS AND ABOVE ONLY
if(intval($staffRank) <= 3  && intval($staffRank) != 0)
{
    // YOU CAN STAY :D
}
else
{
    header('Location: ../login.php');
}

$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);

// GET MEMBERS
$departmentMembers = $pdo->query("SELECT * FROM users WHERE avatar<>''");

?>

<div class="row">
    <div class="col-12">
        <div class="card-box">
            <h4 class="header-title">Select Department Member</h4>
            <form method="post" class="mt-3">
                <div class="row justify-content-center">
                    <div class="col-sm-8">
                        <div class="input-group">
                            <select name="staffID" id="stafflist" class="form-control btn btn-outline-<?php echo $BUTTON_TYPE; ?> dropdown-toggle">
                            <?php
                                foreach($departmentMembers as $row)
                                {
                                    $_SESSION["userID"] = $row['ID'];
                                    if($_POST['staffID'])
                                    {
                                        if($_POST['staffID'] == $row['ID'])
                                        {
                                            echo '<option selected="selected" value="' . $row['ID'] . '">' . $row['name'] . ' - ' . $row['callsign'] . '</option>';
                                        }else
                                        {
                                            echo '<option value="' . $row['ID'] . '">' . $row['name'] . ' - ' . $row['callsign'] . '</option>';
                                        }
                                    }else
                                    {
                                        echo '<option value="' . $row['ID'] . '">' . $row['name'] . ' - ' . $row['callsign'] . '</option>';
                                    }
                                }
                            ?>
                            </select>
                            <span class="input-group-append">
                                <input name="get_staffstats_button" type="submit" class="btn btn-outline-<?php echo $BUTTON_TYPE; ?>" value="Get Profile">
                            </span>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


<?php
if (isset($_POST['get_staffstats_button']) || $_SESSION['OVERRIDEID'])
{
    showStats();
}

function showStats()
{

global $pdo;
    
$currentID = $_POST['staffID'];

if($_SESSION['OVERRIDEID']){$currentID = $_SESSION['OVERRIDEID']; unset($_SESSION['OVERRIDEID']);} //OVERRIDE THE ID WITH THE ONE PASSED BACK THEN KILL IT

$_SESSION['currentStaffStatSearchedID'] = $currentID;

$departmentProfile = $pdo->query("SELECT * FROM users WHERE ID='$currentID'");

foreach($departmentProfile as $row)
{
    $avatar = $row['avatar'];
    $staffname = $row['name'];
    $membercallsign = $row['callsign'];
    $rank = getRoleName($row['rank']);
    $discordID = $row['discordid'];
}

$_SESSION['currentStaffStatSearchedDiscordID'] = $discordID;
$_SESSION['currentStaffStatSearchedName'] = $staffname;
    
    
echo '<div class="row">
                            <div class="col-lg-3">
                                <div class="text-center card-box">
                                    <div class="pt-2 pb-2">
                                        <img src="' . $avatar . '" class="rounded-circle img-thumbnail avatar-xl" alt="profile-image">
                                        <h4 class="mt-3"><a class="text-dark">'. $membercallsign . '</a></h4>
                                        <p class="text-muted">' . $rank . '</p>
                                        <p class="text-muted">Discord Name: '. $staffname . '</p>
                                        <p class="text-muted">Discord ID: ' . $discordID . '</p>

                                    </div>                                    
                                </div>';
                            include "includes/points.inc.php";
                      echo '</div>';
?>
<?php include "includes/changecallsign.inc.php"; ?>
<?php include "includes/certifications.inc.php"; ?>
<?php include "includes/notes.inc.php"; ?>
<?php include "includes/praises.inc.php"; ?>
<?php include "includes/warnings.inc.php"; ?>

<?php
// COC TO SEE STRIKES
if(intval($staffRank) <= 2  && intval($staffRank) != 0)
{
     include "includes/strikes.inc.php";
}
?>
<?php include "includes/profiletimelog.inc.php"; ?>
<?php

echo '</div>';   

}
?>