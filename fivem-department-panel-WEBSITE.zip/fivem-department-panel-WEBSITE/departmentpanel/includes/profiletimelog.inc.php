<?php
require_once(__DIR__ . "/../config.php");
session_start();

$staffRank = $_SESSION['staffrank'];
$currentDiscordID = $_SESSION['currentStaffStatSearchedDiscordID'];
$currentName = $_SESSION['currentStaffStatSearchedName'];

try{
	$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
} catch(PDOException $ex)
{
	echo "Could not connect -> ".$ex->getMessage();
	die();
}

$result = $pdo->query("SELECT * FROM timelogs WHERE discordid='$currentDiscordID' ORDER BY id DESC");

?>

                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Time Logs</h4>
                                        <table id="basic-datatable" class="table dt-responsive nowrap">
                                            <thead>
                                                <tr>
                                                <th>Duration</th>
                                                <th>Info</th>
                                                <th>Good or Bad?</th>
                                                <th>Date</th>
                                                <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
										<?php
											foreach($result as $row)
											{
												$duration = gmdate("H:i", $row['time']);
												
												echo  '<td>'. $duration .'</td>
													  <td>'. $row['info'] .'</td>
													  <td>'. $row['goodbad'] .'</td>
													  <td>'. $row['stamp'].'</td>';
												//FOR HEADS AND ABOVE
												if(intval($staffRank) <= 2  && intval($staffRank) != 0)
												{
													echo '<td><a href="actions/member-actions.php?timelogID=' . $row['ID'] . '">Remove</a></td>';
												}
												echo  '</tr>';
												
											}
										?>
                                            </tbody>
                                        </table>
                                    </div> 
                            </div>
                        </div>

