<?php
include __DIR__ . '/../config.php';
?>
<div class="col-lg-4">
    <div class="card">
        <div class="card-body">

            <form id="form" action="actions/member-actions.php" method="POST" onsubmit="this.callsign_btn.hidden = true;"> 
                <div class="form-group mb-4">
                    <label for="callsign">Callsign + Name</label>
                    <input required placeholder="<?php echo $DEPARTMENT_EXAMPLE_CALLSIGN; ?>" id="callsign" name="callsign" type="text" class="form-control">
                </div>

                <button type="submit" name="callsign_btn" class="btn btn-outline-<?php echo $BUTTON_TYPE; ?> waves-effect waves-light">Update</button>
            </form>

        </div>
    </div>

    <div class="card">
        <div class="card-body">

            <form id="form" action="actions/member-actions.php" method="POST" onsubmit="this.certification_btn.hidden = true;"> 
                <div class="form-group mb-4">
                    <label for="certification">Certifications</label>
                    <select name="certification" id="certification" class="form-control btn btn-outline-<?php echo $BUTTON_TYPE; ?> dropdown-toggle">
                    <?php
                      foreach ($CERTS as $name) {
                    ?>
                        <option value="<?php echo $name; ?>"><?php echo $name; ?></option>
                    <?php
                      }
                    ?>
                    </select>
                </div>
                <button type="submit" name="certification_btn" class="btn btn-outline-<?php echo $BUTTON_TYPE; ?> waves-effect waves-light">Add</button>
            </form>

        </div>
    </div>


</div>
