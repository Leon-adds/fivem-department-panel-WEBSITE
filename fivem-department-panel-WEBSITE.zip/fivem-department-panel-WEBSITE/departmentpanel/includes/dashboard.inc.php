<?php
require_once(__DIR__ . "/../config.php");
require_once(__DIR__ . "/../actions/points.php");
session_start();
$user_id = $_SESSION['id'];
$discordid = $_SESSION['staffid'];
$userID = $_SESSION['userID'];

$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);

$warnings = $pdo->query("SELECT * FROM warnings ORDER BY id DESC");
$strikes = $pdo->query("SELECT * FROM strikes ORDER BY id DESC");
$praises = $pdo->query("SELECT * FROM praises ORDER BY id DESC");
$users = $pdo->query("SELECT * FROM users ORDER BY id DESC");

$alltime = $pdo->query("SELECT SUM(time) FROM timelogs");

foreach($alltime as $row2)
{
    $totalTime = $row2['SUM(time)'];

    $h = intval($totalTime / 3600);
    $m = intval(($totalTime / 60) - ($h * 60));

}

$timelog24hr = $pdo->query("SELECT SUM(time) FROM timelogs WHERE timelogs.stamp > DATE_SUB(CURDATE(), INTERVAL 1 DAY)");

foreach($timelog24hr as $row3)
{
    $totalTime24 = $row3['SUM(time)'];

    $h24 = intval($totalTime24 / 3600);
    $m24 = intval(($totalTime24 / 60) - ($h24 * 60));

}

$yourTotal = $pdo->query("SELECT SUM(time) FROM timelogs WHERE discordid='$discordid'");

foreach($yourTotal as $row4)
{
    $yourTotalTime = $row4['SUM(time)'];

    $yourh = intval($yourTotalTime / 3600);
    $yourm = intval(($yourTotalTime / 60) - ($yourh * 60));

}


?>
                        <div class="p-3" style="position: absolute; top: 0; right: 0; z-index: 2; margin-top: 60px;">
                            <div aria-live="polite" aria-atomic="true" style="position: relative; min-height: 200px;">
                                <div>
                                    <?php
                                    $announcements = $pdo->query("SELECT * FROM announcements ORDER BY id DESC");

                                    foreach($announcements as $row5)
                                    {
                                        echo '<div class="toast fade show" role="alert" aria-live="assertive" aria-atomic="true" data-toggle="toast">
                                        <div class="toast-header">
                                            <img src="'.$DEPARTMENT_LOGO.'" alt="brand-logo" height="20" class="mr-1" />
                                            <strong class="mr-auto">'.$DEPARTMENT_NAME.' Announcement</strong>
                                            <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="toast-body">' . $row5['details'] . '</div>
                                    </div>';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-xl-4">
                                <div class="widget-rounded-circle card-box">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="avatar-lg rounded-circle bg-soft-<?php echo $BUTTON_TYPE; ?> border-<?php echo $BUTTON_TYPE; ?> border">
                                                <i class="fe-heart font-22 avatar-title text-<?php echo $BUTTON_TYPE; ?>"></i>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark mt-1"><span data-plugin="counterup"><?php echo sizeof($praises->fetchAll()) ?></span></h3>
                                                <p class="text-muted mb-1 text-truncate">Total Praises</p>
                                            </div>
                                        </div>
                                    </div> 
                                </div> 
                            </div>
                            <div class="col-md-6 col-xl-4">
                                <div class="widget-rounded-circle card-box">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="avatar-lg rounded-circle bg-soft-<?php echo $BUTTON_TYPE; ?> border-<?php echo $BUTTON_TYPE; ?> border">
                                                <i class="fe-alert-circle font-22 avatar-title text-<?php echo $BUTTON_TYPE; ?>"></i>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark mt-1"><span data-plugin="counterup"><?php echo sizeof($warnings->fetchAll()) ?></span></h3>
                                                <p class="text-muted mb-1 text-truncate">Total Warnings</p>
                                            </div>
                                        </div>
                                    </div> 
                                </div> 
                            </div>
                            <div class="col-md-6 col-xl-4">
                                <div class="widget-rounded-circle card-box">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="avatar-lg rounded-circle bg-soft-<?php echo $BUTTON_TYPE; ?> border-<?php echo $BUTTON_TYPE; ?> border">
                                                <i class="fe-alert-triangle font-22 avatar-title text-<?php echo $BUTTON_TYPE; ?>"></i>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark mt-1"><span data-plugin="counterup"><?php echo sizeof($strikes->fetchAll()) ?></span></h3>
                                                <p class="text-muted mb-1 text-truncate">Total Strikes</p>
                                            </div>
                                        </div>
                                    </div> 
                                </div> 
                            </div> 
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-xl-4">
                                <div class="card-box">
                                <div class="p-2 text-center">
                                    <i class="mdi mdi-timer text-<?php echo $BUTTON_TYPE; ?> mdi-24px"></i>
                                    <h3><span data-plugin="counterup"><?php echo $h24; ?></span> Hours, <span data-plugin="counterup"> <?php echo $m24; ?></span> Minutes</h3>
                                    <p class="text-muted font-15 mb-0">Total Time Logged - 24 Hours</p>
                                </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <div class="card-box">
                                <div class="p-2 text-center">
                                    <i class="mdi mdi-timer text-<?php echo $BUTTON_TYPE; ?> mdi-24px"></i>
                                    <h3><span data-plugin="counterup"><?php echo $h; ?></span> Hours, <span data-plugin="counterup"> <?php echo $m; ?></span> Minutes</h3>
                                    <p class="text-muted font-15 mb-0">Total Time Logged - All Time</p>
                                </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-xl-4">
                                <div class="card-box">
                                <div class="p-2 text-center">
                                    <i class="mdi mdi-timer text-<?php echo $BUTTON_TYPE; ?> mdi-24px"></i>
                                    <h3><span data-plugin="counterup"><?php echo $yourh; ?></span> Hours, <span data-plugin="counterup"> <?php echo $yourm; ?></span> Minutes</h3>
                                    <p class="text-muted font-15 mb-0"><strong>Your</strong> Total Time Logged</p>
                                </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-2 col-xl-2">
                            </div>
                            <div class="col-sm-4 col-xl-4">
                                    <div class="card-box">
                                    <div class="p-2 text-center">
                                        <i class="mdi mdi-account-group text-<?php echo $BUTTON_TYPE; ?> mdi-24px"></i>
                                        <h3><span data-plugin="counterup"><?php echo sizeof($users->fetchAll()) ?></span></h3>
                                        <p class="text-muted font-15 mb-0">Total Members</p>
                                    </div>
                                    </div>
                            </div>
                            <div class="col-sm-4 col-xl-4">
                                    <div class="card-box">
                                    <div class="p-2 text-center">
                                        <i class="mdi mdi-star-four-points text-<?php echo $BUTTON_TYPE; ?> mdi-24px"></i>
                                        <h3><span data-plugin="counterup"><?php echo getPoints($_SESSION['staffid']) ?></span></h3>
                                        <p class="text-muted font-15 mb-0"><strong>Your</strong> Points</p>
                                    </div>
                                    </div>
                            </div>
                            <div class="col-sm-2 col-xl-2">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-xl-4">
                                <div class="widget-rounded-circle card-box">
                                    <div class="row align-items-center">
                                        <div class="col-auto">
                                            <div class="avatar-lg">
                                                <img src="<?php echo $HEAD2IMAGE; ?>" class="img-fluid rounded-circle" alt="user-img" />
                                            </div>
                                        </div>
                                        <div class="col">
                                            <h5 class="mb-1 mt-2"><?php echo $HEAD2NAME; ?></h5>
                                            <p class="mb-2 text-muted"><?php echo $HEAD2RANK; ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-4">
                                <div class="widget-rounded-circle card-box">
                                    <div class="row align-items-center">
                                        <div class="col-auto">
                                            <div class="avatar-lg">
                                                <img src="<?php echo $HEAD1IMAGE; ?>" class="img-fluid rounded-circle" alt="user-img" />
                                            </div>
                                        </div>
                                        <div class="col">
                                            <h5 class="mb-1 mt-2"><?php echo $HEAD1NAME; ?></h5>
                                            <p class="mb-2 text-muted"><?php echo $HEAD1RANK; ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-4">
                                <div class="widget-rounded-circle card-box">
                                    <div class="row align-items-center">
                                        <div class="col-auto">
                                            <div class="avatar-lg">
                                                <img src="<?php echo $HEAD3IMAGE; ?>" class="img-fluid rounded-circle" alt="" />
                                            </div>
                                        </div>
                                        <div class="col">
                                            <h5 class="mb-1 mt-2"><?php echo $HEAD3NAME; ?></h5>
                                            <p class="mb-2 text-muted"><?php echo $HEAD3RANK; ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>