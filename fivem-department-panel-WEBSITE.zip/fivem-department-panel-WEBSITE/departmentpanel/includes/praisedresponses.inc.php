<?php
require_once(__DIR__ . "/../config.php");
session_start();

$user_id = $_SESSION['id'];
$discordid = $_SESSION['staffid'];

try{
	$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
} catch(PDOException $ex)
{
	echo "Could not connect -> ".$ex->getMessage();
	die();
}

$result = $pdo->query("SELECT * FROM praises ORDER BY id DESC");

$yourpraises = $pdo->query("SELECT * FROM praises WHERE member_discordid='$discordid'");

?>

						<div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                    	<span class="badge badge-success badge-pill float-right"><?php echo sizeof($yourpraises->fetchAll()) ?></span>
                                        <h4 class="header-title">Praises</h4>
                                        <table id="basic-datatable" class="table dt-responsive nowrap">
                                            <thead>
                                                <tr>
                                                <th>Officer</th>
                                                <th>Praise</th>
												<th>Issuer</th>
                                                <th>Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
										<?php
											foreach($result as $row)
											{
												$date_time = gmdate("d.m.Y h:i:s A", $row['time']);
												$officerid =  $row['member_discordid'];

												$result2 = $pdo->query("SELECT callsign FROM users WHERE discordid='$officerid'");
												foreach($result2 as $row2)
												{
												$currentCallsign = $row2['callsign'];
												echo '<td>'. $currentCallsign .'</td>';
												}
												echo  '<td>'. $row['reason'] .'</td>
													   <td>'. $row['senders_name'] . '</td>
													   <td>'. $date_time .'</td>';
												echo  '</tr>';
												
											}
										?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
