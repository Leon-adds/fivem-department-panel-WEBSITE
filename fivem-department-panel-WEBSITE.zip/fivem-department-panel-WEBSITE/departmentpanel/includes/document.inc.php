<?php
require_once(__DIR__ . "/../config.php");
session_start();

$discordid = $_SESSION['staffid'];


$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);

$result = $pdo->query("SELECT * FROM documents ORDER BY id DESC");

?>

                            <div class="col-lg-6">
                                <h4 class="page-title">Documents List</h4>
                                <div class="card-box">
                                    <div class="table-responsive">
                                        <table class="table mb-0">
                                            <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Link</th>
                                                <th></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php
											foreach($result as $row)
											{
												echo '<td>' . $row['title'] . '</td>
                                                     <td>' . $row['link'] . '</td>';
                                                if(intval($staffRank) <= 1  && intval($staffRank) != 0)
                                                {
                                                    echo '<td><a href="actions/member-actions.php?documentID=' . $row['ID'] . '">Remove</a></td>';
                                                }
												echo  '</tr>';
												
											}
											?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div> <!-- end card-box -->
                            </div> <!-- end col -->

