<?php
require_once(__DIR__ . "/../config.php");
session_start();

$discordid = $_SESSION['staffid'];

try{
	$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
} catch(PDOException $ex)
{
 echo "Could not connect -> ".$ex->getMessage();
	 
	die();
}

$result = $pdo->query("SELECT * FROM timelogs WHERE discordid='$discordid' ORDER BY id DESC");

$timelogs = $pdo->query("SELECT * FROM timelogs WHERE discordid='$discordid'");

if (!$result)
{
	$_SESSION['error'] = $pdo->errorInfo();
	header('Location: 404.php');
	die();
}
?>

							<div class="col-lg-6">
                                <div class="card-box">
                                	<span class="badge badge-success badge-pill float-right"><?php echo sizeof($timelogs->fetchAll()) ?></span>
                                    <h4 class="header-title">Logs</h4>
                                    <div class="table-responsive">
                                        <table class="table mb-0">
                                            <thead>
                                            <tr>
                                                <th>Duration</th>
                                                <th>Info</th>
                                                <th>Good or Bad?</th>
                                                <th>Date</th>
                                            </tr>
                                            </thead>
                                            <tbody>
										<?php
											foreach($result as $row)
											{
												$duration = gmdate("H:i", $row['time']);
												
												echo  '<td>'. $duration .'</td>
													  <td>'. $row['info'] .'</td>
													  <td>'. $row['goodbad'] .'</td>
													  <td>'. $row['stamp'].'</td>';
												echo  '</tr>';
												
											}
										?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

