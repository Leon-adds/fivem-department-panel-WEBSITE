<?php
require_once(__DIR__ . "/../config.php");
session_start();

$user_id = $_SESSION['id'];

$staffRank = $_SESSION['staffrank'];
 
// COC AND ABOVE ONLY
if(intval($staffRank) <= 2  && intval($staffRank) != 0)
{
    // YOU CAN STAY :D
}
else
{
    header('Location: ../login.php');
}

try{
	$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
} catch(PDOException $ex)
{
	echo "Could not connect -> ".$ex->getMessage();
	die();
}

$result = $pdo->query("SELECT ID, name, callsign, discordid, points FROM users WHERE avatar<>''");

?>

						<div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Member Statistics</h4>
                                        <table id="basic-datatable" class="table dt-responsive nowrap">
                                            <thead>
                                                <tr>
                                                <th>Discord Name</th>
                                                <th>Discord ID</th>
                                                <th>Callsign + Name</th>
                                                <th>Warns</th>
                                                <th>Strikes</th>
												<th>Praises</th>
												<th>Total Time Logged - 2 Weeks</th>
												<th>Total Time Logged</th>
                                                <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
										<?php
											foreach($result as $row)
											{
												$currentID = $row['ID'];
												$currentName = $row['name'];
												$currentCallsign = $row['callsign'];
												$currentDiscordID = $row['discordid'];
												
												$warns = $pdo->query("SELECT * FROM warnings WHERE member_discordid='$currentDiscordID'");
												$strikes = $pdo->query("SELECT * FROM strikes WHERE member_discordid='$currentDiscordID'");
												$praises = $pdo->query("SELECT * FROM praises WHERE member_discordid='$currentDiscordID'");
												$time = $pdo->query("SELECT * FROM timelogs WHERE discordid='$currentDiscordID'");	
												$timelogged = $pdo->query("SELECT SUM(time) FROM timelogs WHERE discordid='$currentDiscordID'");						

												$result2 = $pdo->query("SELECT SUM(time) FROM timelogs WHERE discordid='$currentDiscordID'");
												foreach($result2 as $row2)
												{
													$totalTime = $row2['SUM(time)'];

													$h = intval($totalTime / 3600);
													$m = intval(($totalTime / 60) - ($h * 60));
													$totalTimeString = "{$h} Hours, {$m} Minutes";

												}	

												// NEW TIMELOGS LAST 2 WEEKS
												$timeAmount = $pdo->query("SELECT * FROM timelogs WHERE discordid='$currentDiscordID' AND timelogs.stamp > DATE_SUB(CURDATE(), INTERVAL 14 DAY)");	
												$result3 = $pdo->query("SELECT SUM(time) FROM timelogs WHERE discordid='$currentDiscordID' AND timelogs.stamp > DATE_SUB(CURDATE(), INTERVAL 14 DAY)");
												foreach($result3 as $row2)
												{
													$totalTime2 = $row2['SUM(time)'];

													$h2 = intval($totalTime2 / 3600);
													$m2 = intval(($totalTime2 / 60) - ($h2 * 60));
													$totalTimeString2 = "{$h2} Hours, {$m2} Minutes";

												}															
											
												echo '<td><form action="/../profile.php" method="post"><input type="hidden" name="staffID" value="' . $currentID . '"><input name="get_staffstats_button" type="submit" class="btn btn-primary" style="background: none!important;border: none;padding: 0!important;font-family: arial, sans-serif;color:#009BFF;" value="' . $currentName . '"></form></td>
													  <td>'. $currentDiscordID . '</td>
													  <td>'. $currentCallsign . '</td>
													  <td>'. sizeof($warns->fetchAll()) .'</td>
													  <td>'. sizeof($strikes->fetchAll()) .'</td>
													  <td>'. sizeof($praises->fetchAll()) .'</td>
													  <td>'. $totalTimeString2 . '&nbsp; |&nbsp; Amount: ' . sizeof($timeAmount->fetchAll()) .'</td>
													  <td>'. $totalTimeString . '&nbsp; |&nbsp; Amount: ' . sizeof($time->fetchAll()) .'</td>';
													  echo '<td><a href="actions/member-actions.php?userID=' . $row['ID'] . '">Remove</a></td>';
													  echo  '</tr>';
												
											}
										?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
