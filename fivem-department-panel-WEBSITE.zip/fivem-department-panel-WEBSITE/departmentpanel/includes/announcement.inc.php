<?php
require_once(__DIR__ . "/../config.php");
session_start();

$discordid = $_SESSION['staffid'];

try{
	$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
} catch(PDOException $ex)
{
 echo "Could not connect -> ".$ex->getMessage();
	die();
}

$result = $pdo->query("SELECT * FROM announcements ORDER BY id DESC");

if (!$result)
{
	$_SESSION['error'] = $pdo->errorInfo();
	header('Location: 404.php');
	die();
}
?>

                            <div class="col-lg-6">
                                <h4 class="page-title">Announcements List</h4>
                                <div class="card-box">
                                    <div class="table-responsive">
                                        <table class="table mb-0">
                                            <thead>
                                            <tr>
                                                <th>Details</th>
                                                <th></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php
											foreach($result as $row)
											{
												echo '<td>' . $row['details'] . '</td>';
                                                if(intval($staffRank) <= 1  && intval($staffRank) != 0)
                                                {
                                                    echo '<td><a href="actions/member-actions.php?announcementID=' . $row['ID'] . '">Remove</a></td>';
                                                }
												echo  '</tr>';
												
											}
											?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div> <!-- end card-box -->
                            </div> <!-- end col -->

