<?php
$staffRank = $_SESSION['staffrank'];
$currentDiscordID = $_SESSION['currentStaffStatSearchedDiscordID'];
$currentName = $_SESSION['currentStaffStatSearchedName'];

try{
    $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
} catch(PDOException $ex)
{
    $_SESSION['error'] = "Could not connect -> ".$ex->getMessage();
    $_SESSION['error_blob'] = $ex;
     
    die();
}

$result = $pdo->query("SELECT * FROM certification WHERE discordid='$currentDiscordID' ORDER BY id DESC");

?>
<div class="col-lg-5">
    <div class="card">
        <div class="card-body">
            <table id="basic-datatable" class="table dt-responsive nowrap">
            <thead>
                <tr>
                <th>Certifications</th>
                <th></th>
                </tr>
            </thead>
            <tbody>
            <?php
                foreach($result as $row)
                {
                    
                    echo  '<td>'. $row['certification'] .'</td>';
                    //FOR SUPERVISORS AND ABOVE
                    if(intval($staffRank) <= 3  && intval($staffRank) != 0)
                    {
                        echo '<td><a href="actions/member-actions.php?certificationID=' . $row['ID'] . '">Remove</a></td>';
                    }
                    echo  '</tr>';
                                                
                }
            ?>
            </tbody>
            </table>
        </div> 
    </div>
</div>


