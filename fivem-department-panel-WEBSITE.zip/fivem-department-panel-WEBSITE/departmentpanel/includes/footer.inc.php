<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                Made with ❤ by <a href="https://discord.com/invite/6Qadcj6">Hamz#0001</a> 
            </div>
        </div>
    </div>
</footer>