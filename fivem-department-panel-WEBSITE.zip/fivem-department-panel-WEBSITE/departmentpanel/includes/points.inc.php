            
            <div class="card-box">
                <div class="mt-2">
                    <h6 class="text-uppercase">POINTS <span class="float-right"><?php echo getPoints($_SESSION['currentStaffStatSearchedDiscordID']) ?> POINTS</span></h6>
                    <div class="progress progress-sm m-0">
                        <div class="progress-bar bg-info" role="progressbar" style="width: <?php echo getPoints($_SESSION['currentStaffStatSearchedDiscordID']) ?>%" aria-valuenow="<?php echo getPoints($_SESSION['currentStaffStatSearchedDiscordID']) ?>" aria-valuemin="0" aria-valuemax="200">
                        </div>
                    </div>
                </div>
            </div> 
  
