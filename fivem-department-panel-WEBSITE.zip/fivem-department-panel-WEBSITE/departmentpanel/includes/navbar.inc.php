<?php
require_once __DIR__ . '/../actions/discord_functions.php';
require_once __DIR__ . '/../config.php';

session_start();
if (empty($_SESSION['logged_in']))
{
  header('Location: login.php');
}

$name = $_SESSION['staffname'];
$avatar = $_SESSION['staffavatar'];
$role = $_SESSION['staffrank'];
$role = getRoleName($role);

$staffRank = $_SESSION['staffrank'];

try{
    $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);
} catch(PDOException $ex)
{
    echo "Could not connect -> ".$ex->getMessage();
    die();
}

$document = $pdo->query("SELECT * FROM documents ORDER BY id ASC");
?>

<style>
.left-side-menu-dark .navbar-custom {
    background: <?php echo $DEPARTMENT_COLOR; ?> !important;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
}

.left-side-menu-dark .left-side-menu .nav-second-level li a, .left-side-menu-dark .left-side-menu .nav-third-level li a {
  color: white !important;
}

.left-side-menu-dark .left-side-menu {
  background: <?php echo $DEPARTMENT_COLOR; ?>  !important;
  border-right: none !important;
  transition: none !important;
  padding-top: 0 !important;
}

.left-side-menu-dark .left-side-menu #sidebar-menu>ul>li>a.active {
  background: #1e272e !important;
}

.left-side-menu-dark .left-side-menu #sidebar-menu>ul>li>a.active span {
  color: white !important;
}

#sidebar-menu>ul>li>a>span {
    vertical-align: middle !important;
    color: black !important;
    font-weight: 400 !important; /* OPTIONAL BUT LOOKS BETTER WITH */
}

#sidebar-menu>ul>li>a i {
    vertical-align: middle !important;
    color: black !important;
    font-weight: 400 !important; /* OPTIONAL */
}

.left-side-menu-dark .left-side-menu #sidebar-menu .menu-title {
  color: white !important;
}

.text-muted {
  color: white !important;
}

.left-side-menu-dark .left-side-menu .nav-second-level li a, .left-side-menu-dark .left-side-menu .nav-thrid-level li:hover a {
  color: black !important; /* IDK, u can add a background on hover instead */
}

.left-side-menu-dark .left-side-menu #sidebar-menu>ul>li>a.active i {
  color: white !important; /* icon color on active */
}

.p-2 p {
   color: black !important;
}

.row .text-right p {
  color: black !important;
}

.pt-2 p {
  color: black !important;
}

.page-item.active .page-link {
      background: <?php echo $DEPARTMENT_COLOR; ?>  !important;
      border-color: <?php echo $DEPARTMENT_COLOR; ?>  !important;
}

.row p {
  color: black !important;
}

.page-title-box .page-title {
  color: black !important;
}

.h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6 {
  color: black !important;
}

.footer a  {
      color: <?php echo $DEPARTMENT_COLOR; ?>  !important;
}


/* DARK MODE */
body.dark-mode {
      background-color: #333333 !important;
}

body.dark-mode.left-side-menu-dark .navbar-custom {
    background: #212121 !important;
}

body.dark-mode.left-side-menu-dark .left-side-menu .nav-second-level li a, .left-side-menu-dark .left-side-menu .nav-third-level li a {
  color: black !important;
}

body.dark-mode.left-side-menu-dark .left-side-menu {
  background: #212121 !important;
  padding-top: 0 !important;
}

body.dark-mode.left-side-menu-dark .left-side-menu #sidebar-menu>ul>li>a span {
    color: white !important;
}

body.dark-mode.left-side-menu-dark .left-side-menu #sidebar-menu>ul>li>a i {
    color: white !important;
}

body.dark-mode.left-side-menu-dark .left-side-menu #sidebar-menu>ul>li>a.active {
  background: #121212 !important;
}

body.dark-mode.left-side-menu-dark .left-side-menu #sidebar-menu>ul>li>a.active span {
  color: white !important;
}

body.dark-mode#sidebar-menu>ul>li>a>span {
    vertical-align: middle !important;
    color: white !important;
    font-weight: 400 !important; /* OPTIONAL BUT LOOKS BETTER WITH */
}

body.dark-mode#sidebar-menu>ul>li>a i {
    vertical-align: middle !important;
    color: white !important;
    font-weight: 400 !important; /* OPTIONAL */
}

body.dark-mode.left-side-menu-dark .left-side-menu #sidebar-menu .menu-title {
  color: white !important;
}

body.dark-mode.text-muted {
  color: white !important;
}

body.dark-mode.left-side-menu-dark .left-side-menu .nav-second-level li a, .left-side-menu-dark .left-side-menu .nav-thrid-level li:hover a {
  color: white !important; /* IDK, u can add a background on hover instead */
}

body.dark-mode.left-side-menu-dark .left-side-menu #sidebar-menu>ul>li>a.active i {
  color: white !important; /* icon color on active */
}

body.dark-mode.p-2 p {
   color: white !important;
}

body.dark-mode.row .text-right p {
  color: white !important;
}

body.dark-mode.pt-2 p {
  color: white !important;
}

body.dark-mode.page-item.active .page-link {
      background: #212121 !important;
      border-color: #212121 !important;
}

body.dark-mode .card-box {
      background: #474747 !important;
}

body.dark-mode .footer {
      background: #212121 !important;
      color: white !important;
}

body.dark-mode .footer a  {
      color: <?php echo $DEPARTMENT_COLOR; ?>  !important;
}

body.dark-mode .page-title-box .page-title {
  color: white !important;
}

body.dark-mode .text-dark {
  color: white !important;
}

body.dark-mode .row .text-right p {
  color: white !important;
}

body.dark-mode .card-box h3 {
  color: white !important;
}

body.dark-mode .row p {
  color: white !important;
}

body.dark-mode .mt-2 {
  color: white !important;
}

body.dark-mode .row .card {
  background: #474747 !important;
}

body.dark-mode .table-striped tbody tr:nth-of-type(odd) {
  background: #212121 !important;
}

body.dark-mode .header-title {
  color: white !important;
}

body.dark-mode .mb-3 {
  color: white !important;
}

body.dark-mode .form-control {
  background: #212121 !important;
  border: none !important;
  color: white !important;
}

body.dark-mode .table {
  color: white !important;
}

body.dark-mode .mb-4 {
  color: white !important;
}

body.dark-mode .table a {
  color: lightblue !important;
}

body.dark-mode .table input {
  color: lightblue !important;
}

body.dark-mode .btn-outline-dark {
  color: white !important;
  border-color: white !important;
  background: transparent !important;
}

body.dark-mode .btn-outline-dark:hover {
  color: black !important;
  border-color: white !important;
  background: white !important;
}

body.dark-mode .page-item.active .page-link {
  background: #212121 !important;
  border-color: #212121 !important;
}

body.dark-mode .row label {
  color: white !important;
}

body.dark-mode .dataTables_info{
  color: white !important;
}

body.dark-mode .toast.show {
  border: none !important;
  background-color: transparent;
  -webkit-box-shadow: 10px 5px 0.5rem 0.9rem rgba(0,0,0,.1) !important;
  -moz-box-shadow: 10px 5px 0.5rem 0.9rem rgba(0,0,0,.1) !important;
  box-shadow: 10px 5px 0.5rem 0.9rem rgba(0,0,0,.1) !important;
}

body.dark-mode .toast.show .toast-header {
  background: #212121 !important;
  color: white !important;
  border-bottom: 2px solid white !important;
}
body.dark-mode .toast.show .toast-header .close {
  color: white;
}

body.dark-mode .toast.show .toast-body {
  background: #212121 !important;
  color: white !important;
}

body.dark-mode #sidebar-menu>ul>li>a:hover {
  background: #1b1b1b !important;
}

body.dark-mode #sidebar-menu>ul>li>ul>li>a:hover {
  background: #1b1b1b !important;
}

body.dark-mode .modal-content {
  background: #333333 !important;
  color: white !important;
}

body.dark-mode .modal-content .modal-header { 
  color: white !important;
}

body.dark-mode .mt-2 h6 {
  color: white !important;
}

body.dark-mode .card .card-body h4 {
  color: white !important;
}

body.dark-mode .modal-content .modal-header h4 {
  color: white !important;
}

body.dark-mode .modal-content .modal-body h6 {
  color: white !important;
}

body.dark-mode .h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6 {
    color: white;
}

</style>
<div class="left-side-menu">

                <div class="slimscroll-menu">

                    <!-- USER BOX -->
                    <div class="user-box text-center">
                        <img src="<?php echo $avatar;?>" alt="user-img" class="rounded-circle avatar-md">
                        <div class="dropdown">
                            <h5 class="text-muted"><?php echo $name;?></h5>
                        </div>
                        <p class="text-muted"><?php echo $role;?></p>
                    </div>

                    <!--- MENU -->
                    <div id="sidebar-menu">

                        <ul class="metismenu" id="side-menu">

                            <li class="menu-title">Main</li>

                            <li>
                                <a href="https://<?php echo PANEL_URL; ?>/index.php">
                                    <i class="fe-airplay"></i>
                                    <span>Dashboard</span>
                                </a>
                            </li>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fe-edit"></i>
                                    <span>Forms</span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <?php
                                  foreach ($FORMS as $name => $redirect) {
                                ?>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="https://<?php echo PANEL_URL; ?>/<?php echo $redirect; ?>"><?php echo $name; ?></a>
                                    </li>
                                </ul>
                                <?php
                                  }
                                ?>
                            </li>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fe-book"></i>
                                    <span>Documents</span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                  <?php

                                  foreach ($document as $row) 
                                  {
                                    $title = $row['title'];
                                    $link = $row['link'];

                                    echo '<li><a href="'.$link.'" target="_blank">'.$title.'</a></li>';
                                  }

                                  ?>
                                </ul>
                            </li>

                            <li>
                                <a href="https://<?php echo PANEL_URL; ?>/praisedresponses.php">
                                    <i class="fe-heart"></i>
                                    <span>Praised Officers</span>
                                </a>
                            </li>

                            <li>
                                <a href="https://<?php echo PANEL_URL; ?>/suggestions.php">
                                    <i class="fe-send"></i>
                                    <span>Suggestions</span>
                                </a>
                            </li>
<?php

if(intval($staffRank) <= 3  && intval($staffRank) != 0)
{
    $supervisorSection = '<li class="menu-title">Supervisor / COC</li>   

                            <li>
                                <a href="https://'.PANEL_URL.'/profile.php">
                                    <i class="fe-user-check"></i>
                                    <span> Member Profiles </span>
                                </a>
                            </li>     

                            <li>
                                <a href="https://'.PANEL_URL.'/timelogresponses.php">
                                    <i class="fe-edit"></i>
                                    <span> Time Log Responses </span>
                                </a>
                            </li>                                        
';
}

if(intval($staffRank) <= 2  && intval($staffRank) != 0)
{
    $supervisorSection = '<li class="menu-title">Supervisor / COC</li>   

                            <li>
                                <a href="https://'.PANEL_URL.'/profile.php">
                                    <i class="fe-user-check"></i>
                                    <span> Member Profiles </span>
                                </a>
                            </li>  

                            <li>
                                <a href="https://'.PANEL_URL.'/stats.php">
                                    <i class="fe-user-check"></i>
                                    <span> Member Stats </span>
                                </a>
                            </li>     

                            <li>
                                <a href="https://'.PANEL_URL.'/timelogresponses.php">
                                    <i class="fe-edit"></i>
                                    <span> Time Log Responses </span>
                                </a>
                            </li>                                        
';
}

if(intval($staffRank) <= 1  && intval($staffRank) != 0)
{
    $headSection = '<li class="menu-title">Heads</li>   

                            <li>
                                <a href="https://'.PANEL_URL.'/headdashboard.php">
                                    <i class="fe-airplay"></i>
                                    <span> Dashboard </span>
                                </a>
                            </li>';
}
?>
<?php if($supervisorSection){echo $supervisorSection;} ?> 
<?php if($supervisorSection){echo $headSection;} ?>   

                        </ul>

                    </div>

                    <div class="clearfix"></div>
                    <div style="padding-top: 40px;" class="text-center">
                       <button onClick="setTheme()" type="button" class="btn btn-outline-dark btn-rounded waves-effect waves-light">Dark Mode</button>
                    </div>
                </div>
            </div>
