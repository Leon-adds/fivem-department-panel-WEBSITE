<?php
session_start();
$staffRank = $_SESSION['staffrank'];

// SUPERVISOR AND ABOVE ONLY
if(intval($staffRank) <= 3  && intval($staffRank) != 0)
{
    // YOU CAN STAY :D
}
else
{
    header('Location: login.php');
}
require_once(__DIR__ . "/../config.php");

$user_id = $_SESSION['id'];

$pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME, DB_USER, DB_PASSWORD);

$result = $pdo->query("SELECT * FROM timelogs ORDER BY id DESC");

?>

				        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Time Logs</h4>
                                        <table id="basic-datatable" class="table dt-responsive nowrap">
                                            <thead>
                                                <tr>
                                                <th>Callsign</th> 
                                                <th>Discord ID</th>
                                                <th>Duration</th>
                                                <th>Info</th>
                                                <th>Good or Bad?</th>
                                                <th>Date</th>
                                                <th></th>
                                                
                                                </tr>
                                            </thead>
                                            <tbody>
										<?php
											foreach($result as $row)
											{
                                                $usersDiscord = $row['discordid'];

                                                $result2 = $pdo->query("SELECT * FROM users WHERE discordid='$usersDiscord'");

                                                foreach ($result2 as $row2)
                                                {
                                                    $usersCallsign = $row2['callsign'];
                                                }

												$duration = gmdate("H:i", $row['time']);
												
												echo  '<td>'. $usersCallsign .'</td>
                                                      <td>'. $row['discordid'] .'</td>
													  <td>'. $duration .'</td>
													  <td>'. $row['info'] .'</td>
													  <td>'. $row['goodbad'] .'</td>
													  <td>'. $row['stamp'].'</td>';
												//FOR COC AND ABOVE
												if(intval($staffRank) <= 2  && intval($staffRank) != 0)
												{
													echo '<td><a href="actions/member-actions.php?timelogID=' . $row['ID'] . '">Remove</a></td>';
												}
												echo  '</tr>';
												
											}
										?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
