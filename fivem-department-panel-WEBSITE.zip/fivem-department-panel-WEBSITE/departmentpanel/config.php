<?php

// SQL DATABASE CONNECTION
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'departmentpanel');


// LINK //
define('PANEL_URL', 'department.hamz.dev');


// DISCORD INTAGRATION // 
define('token', 'YOUR-TOKEN-HERE');
define('guildID', 'YOUR-GUILD-ID-HERE');
$OAUTH2_CLIENT_ID = "YOUR-CLIENT-ID-HERE";
$OAUTH2_CLIENT_SECRET = "YOUR-CLIENT-SECRET-HERE";


// GENERAL CONFIGURATION //
$DEPARTMENT_NAME = "LSPD";
$BUTTON_TYPE = "info"; // info - success - warning - danger
$DEPARTMENT_LOGO = "https://imgur.com/DzVw4e8.jpg";
$DEPARTMENT_COLOR = "#009EFF";
$DEPARTMENT_EXAMPLE_CALLSIGN = "4L-30 | L. ADDS";

// HEADS TEAM
$HEAD1NAME = "L. ADDS";
$HEAD1RANK = "Chief";
$HEAD1IMAGE = "https://imgur.com/DzVw4e8.jpg";

$HEAD2NAME = "L. ADDS";
$HEAD2RANK = "Deputy Chief";
$HEAD2IMAGE = "https://imgur.com/DzVw4e8.jpg";

$HEAD3NAME = "L. ADDS";
$HEAD3RANK = "Assistant Chief";
$HEAD3IMAGE = "https://imgur.com/DzVw4e8.jpg";


// PERMISSIONS - Role ID Based
// 1 = Head Permissions
// 2 = Chain Of Command Permissions
// 3 = Supervisor Permissions
// 4 + = Regular Department Member Permissions
$PERMS = [
	"771717823872499712" => 1,
	"771717851567751188" => 2,
	"771717827363078164" => 3,
	"771717820522037259" => 4,
	"802623343831679017" => 5,
];
$PERMSNAME = [
	1 => "Head",
	2 => "Chain Of Command",
	3 => "Supervisor",
	4 => "Corporal",
	5 => "Officer",
];


// FORMS SIDE MENU - When you create your forms add it here
$FORMS = [
	"Time Log" => "forms/timelogform.php",
	"Example Form" => "forms/exampleform.php",
];

// CERTIFICATIONS
$CERTS = [
	"Pursuit",
	"K9",
	"MBU",
	"AIR",
];


// LOGGING //
define('LOGS_COLOR', '40703'); // Decimal
define('LOGS_IMAGE', 'https://imgur.com/DzVw4e8.jpg');

$TIMELOG_CHANNEL_ID = "718068381068165121";
$SUGGESTIONSLOG_CHANNEL_ID = "718068381068165121";
$ANOUNCEMENTSLOG_CHANNEL_ID = "718068381068165121";
$DOCUMENTSLOG_CHANNEL_ID = "718068381068165121";
$CERTLOG_CHANNEL_ID = "718068381068165121";
$WARN_CHANNEL_ID = "718068381068165121";
$NOTE_CHANNEL_ID = "718068381068165121";
$STRIKE_CHANNEL_ID = "718068381068165121";
$PRAISE_CHANNEL_ID = "718068381068165121";
$REMOVEACTION_CHANNEL_ID = "718068381068165121";
$CALLSIGN_CHANNEL_ID = "718068381068165121";

?>
