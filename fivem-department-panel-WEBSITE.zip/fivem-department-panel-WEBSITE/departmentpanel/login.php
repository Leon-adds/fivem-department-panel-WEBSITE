<?php
require_once(__DIR__ . "/config.php");
session_start();
$DISCORD_LOGIN_URL = "https://discord.com/api/oauth2/authorize?client_id=".$OAUTH2_CLIENT_ID."&redirect_uri=https%3A%2F%2F".PANEL_URL."%2Factions%2Fregister.php&response_type=code&scope=identify%20email%20guilds"; 
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>Login | <?php echo $DEPARTMENT_NAME; ?> Panel</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Department Panel by Hamz#0001" name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
        <style>
            body {
              background: #333333 !important
            }
            
            .card {
              background: #212121 !important;
            }
            
            .card .text-muted {
              color: white !important;
            }
        </style>
    </head>

    <body>
        <div class="account-pages mt-5 mb-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5 mt-5">
                        <div class="card">

                            <div class="card-body p-4">
                                
                                <div class="text-center w-75 m-auto">
                                        <span><img src=" <?php echo $DEPARTMENT_LOGO; ?> " alt="LOGO" height="60"></span>
                                    <h4 class="text-muted mb-3 mt-3"><?php echo $DEPARTMENT_NAME; ?> PANEL</h4>
                                    <p class="text-muted mb-4 mt-3">You will need to login using discord.</p>
                                </div>

                                <form action="">
                                    <div class="form-group mb-0 text-center">
                                        <input id="mainBTN" class="btn btn-outline-<?php echo $BUTTON_TYPE; ?> btn-block" type=button onClick="location.href='<?php echo $DISCORD_LOGIN_URL; ?>'" value='Log In'>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <footer class="footer footer-alt">
            <strong>Department Panel</strong> by <a href="https://discord.com/invite/6Qadcj6" class="text-white-50">Hamz#0001</a> 
        </footer>

        <!-- JS PLUGINS -->
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/js/app.min.js"></script>   
    </body>
</html>