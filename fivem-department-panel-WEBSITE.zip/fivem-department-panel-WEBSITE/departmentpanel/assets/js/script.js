
  let element = document.body;
  let theme = localStorage.getItem("theme");

  if(theme === "dark") {
    element.classList.add("dark-mode");
  } else if(theme === "light") {
    element.classList.remove("dark-mode");
  }
  console.log("test");

function setTheme() {
    
    let element = document.body;
    element.classList.toggle("dark-mode");

    if(localStorage.getItem("theme") === "light") {
      localStorage.setItem("theme", "dark");
    } else if(localStorage.getItem("theme") === "dark") {
      localStorage.setItem("theme", "light");
    } else {
      localStorage.setItem("theme", "dark");
    }
    console.log(localStorage.getItem("theme"));

}